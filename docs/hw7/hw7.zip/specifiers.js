export const specifiers = {
    textareaId: "new-post-text",
    postsContainerId: "posts-container",
    addPostButtonId: "add-post",
    postElementClass: "post",
    postElementIdSuffix: "post-",
    postElementTextId: 'post-text',
    postLikesNumberClass: 'post-likes-number',
    postLikeButtonClass: 'post-like-button',
    postDeleteButtonClass: 'delete-post'
}