// Do not change code below this line
function notify(text){
    window.clientNotifiedText = text;
}