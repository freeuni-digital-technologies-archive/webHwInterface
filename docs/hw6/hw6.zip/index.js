
function getCalculatorElement() {
	return `
		<div id="calculator">
			<input id="number1">
			<input id="number2">
			<button id="add">+</button>
			<button id="substract">-</button>
			<span id="result"></span>
		</div>
	`
}
